#!/usr/bin/env bash
set -eu
set -x
git log -3 --oneline HEAD
git show 39d9c5a:docs/architecture/adr/0001-platform-foundation.md | rg -A3 'creator console reads bundled|No authentication or authorisation|Media is not served at all|No signed access path for originals|locally generated placeholder'
git show 7b62ae1:README.md | rg 'All endpoints are public and read-only'
git show 39d9c5a:README.md | rg 'Local demonstration|catalogue endpoints below are public'
head -12 README.md
rg -n 'Amendment|ADR-0002|No user identity|Reviewed preview bytes only' docs/architecture/adr/0001-platform-foundation.md
rg '^## ' docs/architecture/adr/0002-approved-preview-capability.md
if rg -n 'night-bus|field-recording|keyboard-mechanics|untitled-workshop|Rainspace' api/app/api/catalog.py; then exit 1; else echo 'No pilot release or creator names in catalog.py'; fi
git show 39d9c5a:web/public/editions/night-bus-teaser.mp4 | shasum -a 256
shasum -a 256 api/app/api/derivatives/night-bus-teaser.mp4
ffprobe -v error -show_entries stream=codec_name,codec_type:format=duration -of json api/app/api/derivatives/night-bus-teaser.mp4
docker compose exec -T api alembic current
docker compose exec -T api pytest -v tests/test_catalog.py tests/test_draft_previews.py tests/test_derivative_access.py
curl -fsS http://localhost:8010/api/creators/demo
curl -fsS http://localhost:8010/api/creators/demo/catalog/night-bus-short-film/preview
curl -fsS -H 'Range: bytes=0-15' -D - -o /dev/null http://localhost:8010/api/creators/demo/catalog/night-bus-short-film/preview/bytes
docker compose exec -T db sh -c 'psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Atc "SELECT c.slug,i.slug,i.status,i.approved_preview_id FROM content_items i JOIN creators c ON c.id=i.creator_id ORDER BY c.slug,i.slug"'
rg 'display_name:|illustrative preview' web/src/data/fixtures.ts
rg -n 'Demo Creator|Cloud|Live playback and persistent|different origins' README.md
rg -n 'CORS_ORIGINS=' .env.example
gh repo view Resonant-Jones/RainSpace --json homepageUrl
gh api repos/Resonant-Jones/RainSpace/deployments --jq 'map({environment,ref})'

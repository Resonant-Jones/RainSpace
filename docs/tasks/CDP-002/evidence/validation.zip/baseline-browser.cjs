const { chromium } = require('./web/node_modules/playwright');
(async () => {
const browser=await chromium.launch()
try {
const p=await browser.newPage()
await p.goto('http://127.0.0.1:5173/')
const banner=p.getByTestId('demo-banner')
await banner.waitFor()
console.log('Disclosure visible without click:', await banner.getByText(/Sign-in, checkout/).isVisible())
console.log('Source visible without click:', await banner.getByText(/Catalogue source/).isVisible())
console.log('Direct static teaser HTTP:',(await p.request.get('http://127.0.0.1:5173/editions/night-bus-teaser.mp4')).status())
await p.screenshot({path:'/tmp/rainspace-cdp002.GDOtzg/before.png'})
} finally { await browser.close() }
})().catch(e=>{console.error(e);process.exitCode=1})

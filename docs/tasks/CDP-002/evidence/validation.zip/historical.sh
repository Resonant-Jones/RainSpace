#!/usr/bin/env bash
set -eu
set -x
git diff --name-status 39d9c5a..3e6fcbe
git show 39d9c5a:web/src/components/DemoBanner.tsx
git show 39d9c5a:docker-compose.yml | rg CORS_ORIGINS
git show 39d9c5a:.env.example | rg '^CORS_ORIGINS='
git show 39d9c5a:api/app/api/catalog.py | rg -A8 'original seeded releases'
git show 39d9c5a:web/src/data/fixtures.ts | head -11
git show 39d9c5a:README.md | rg -i 'mirror|fixtures' || true
git show 7b62ae1:README.md | rg -A2 '^> \*\*Status'
git show 39d9c5a:README.md | head -12
rg CORS_ORIGINS docker-compose.yml .env.example
git diff --cached --numstat -- web/public/editions api/app/api/derivatives

const {chromium}=require(process.cwd()+'/web/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch()
 try {
 const root='https://venerable-treacle-a445f3.netlify.app';
 const page=await browser.newPage()
 const home=await page.goto(root)
 console.log('Netlify root',home.status(),await page.title())
 const detail=await page.goto(root+'/videos/night-bus-short-film')
 console.log('Release route',detail.status())
 console.log('Headings',(await page.getByRole('heading').allTextContents()).join(' | '))
 const play=page.getByRole('button',{name:/play teaser/i})
 console.log('Play button count',await play.count())
 if(await play.count()){
 await play.click()
 await page.waitForFunction(()=>document.querySelector('video')?.currentTime>0,{},{timeout:12000})
 console.log('Played',await page.locator('video').evaluate(v=>new URL(v.currentSrc).pathname))
 }
 for(const path of ['/editions/night-bus-teaser.mp4','/api/creators/demo/catalog/night-bus-short-film/preview/bytes']){
   const r=await page.request.get(root+path,{headers:{Range:'bytes=0-15'}})
   console.log(path,r.status(),r.headers()['content-type'],'MP4 signature:',(await r.body()).subarray(4,8).toString()==='ftyp')
 }
 } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1})

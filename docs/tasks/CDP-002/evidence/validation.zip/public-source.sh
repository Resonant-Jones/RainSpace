#!/usr/bin/env bash
set -eu
set -x
gh repo view Resonant-Jones/RainSpace --json visibility
python3 - <<'PY'
import urllib.request
url = 'https://raw.githubusercontent.com/Resonant-Jones/RainSpace/39d9c5a/web/public/editions/night-bus-teaser.mp4'
request = urllib.request.Request(url, headers={'Range': 'bytes=0-15'})
with urllib.request.urlopen(request, timeout=15) as reply:
    print('Historical Git blob, unauthenticated:', reply.status, 'MP4 signature:', reply.read(16)[4:8] == b'ftyp')
PY

"""Check the staged task and a built publish directory without printing credentials."""
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

def git(*args):
    return subprocess.check_output(["git", *args])

dist = Path(sys.argv[1])
assert (dist / "index.html").is_file() and (dist / "editions/contact-sheet.jpg").is_file()
files = sorted(p for p in dist.rglob("*") if p.is_file())
print("Publish directory", [str(p.relative_to(dist)) for p in files])
assert not any(p.suffix in (".mp4", ".mov", ".webm") for p in files)
known = []
for line in Path(".env").read_text().splitlines() if Path(".env").exists() else []:
    key, sep, value = line.partition("=")
    value = value.strip().strip("'").strip('"')
    if sep and key.strip() == "DRAFT_PREVIEW_TOKEN" and len(value) >= 32:
        known.append(value.encode())
# Known local values and conventional provider/private-key formats.
pattern = re.compile(rb"(?:-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{35,}|sk_live_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{16}|nfp_[A-Za-z0-9]{25,})")
def inspect(name, data):
    assert not any(secret in data for secret in known), f"Local credential match in {name}"
    assert not pattern.search(data), f"Credential signature in {name}"
    if name.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for member in archive.namelist():
                inspect(member, archive.read(member))

names = git("diff", "--cached", "--name-only", "--diff-filter=ACMR", "-z").decode().split("\0")[:-1]
assert names, "Run after staging the task"
for name in names:
    assert name in {".env.example", "README.md", "docker-compose.yml", "api/Dockerfile", "api/app/seed_demo.py", "web/vite.config.ts"} or name.startswith((
        "api/app/api/", "api/alembic/versions/", "api/tests/", "docs/architecture/adr/", "docs/tasks/CDP-002/", "web/src/", "web/e2e/")), name
    inspect(name, git("show", ":" + name))
for p in files:
    inspect(str(p), p.read_bytes())
print("Staged paths inside task scope; fixture output contains no movie")
print("Local capability values checked:", len(known), "| credential matches: 0")
